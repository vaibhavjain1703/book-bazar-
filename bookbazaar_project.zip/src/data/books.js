export const books = [
  { title: "Clean Code", author: "Robert Martin", genre: "Programming", publisher: "Pearson", price: 600 },
  { title: "Atomic Habits", author: "James Clear", genre: "Self Help", publisher: "Penguin", price: 450 },
  { title: "Harry Potter", author: "J.K. Rowling", genre: "Fiction", publisher: "Bloomsbury", price: 700 },
  { title: "The Pragmatic Programmer", author: "Andrew Hunt", genre: "Programming", publisher: "Pearson", price: 650 },
  { title: "Think and Grow Rich", author: "Napoleon Hill", genre: "Self Help", publisher: "HarperCollins", price: 350 },
  { title: "The Alchemist", author: "Paulo Coelho", genre: "Fiction", publisher: "HarperCollins", price: 500 },
  { title: "Deep Work", author: "Cal Newport", genre: "Self Help", publisher: "Penguin", price: 400 },
  { title: "Design Patterns", author: "Erich Gamma", genre: "Programming", publisher: "Pearson", price: 800 },
  { title: "The Power of Habit", author: "Charles Duhigg", genre: "Self Help", publisher: "Random House", price: 420 },
  { title: "You Don’t Know JS", author: "Kyle Simpson", genre: "Programming", publisher: "O'Reilly", price: 550 }
];
